# SotsiaalAI CSS etapp 13q — service-map form-control bridge

## Eesmärk

Etapi 13q eesmärk on lõpetada vormiväljade tokenipere esimene omandivoor: allesolevad service-map vormiväljade `--input-*` otsedefinitsioonid liiguvad `--service-map-input-*` alias-tokenitesse ning üldised `--input-*` tokenid jäävad ainult bridge-kihiks.

Scope ainult:

- `app/styles/features/service-map/desktop/base.css`
- `app/styles/features/service-map/desktop/pre-inquiry-agent.css`

## Alusseis pärast 13p

Pärast etappi 13p jäi form-control direct-võlg ainult service-map failidesse:

| Fail | Direct definitsioone |
|---|---:|
| `app/styles/features/service-map/desktop/base.css` | 7 |
| `app/styles/features/service-map/desktop/pre-inquiry-agent.css` | 1 |

Form-control mõõdikud pärast 13p:

| Mõõdik | Väärtus |
|---|---:|
| `feature-direct-definition` | 8 |
| `feature-bridge` | 47 |
| `other` | 0 |
| Projekti `!important` arv | 2025 |

## Muudatused

### `app/styles/features/service-map/desktop/base.css`

HC service-map vormiväljade väärtused liiguvad `--service-map-input-*` alias-tokenitesse.

Enne:

```css
--input-bg: #000;
--input-bg-hover: #000;
--input-bg-focus: #000;
--input-flat-bg: #000;
--input-flat-bg-hover: #000;
--input-text: var(--hc-accent, #ffea00);
--input-placeholder: rgba(255, 234, 0, 0.92);
```

Pärast:

```css
--service-map-input-bg: #000;
--service-map-input-bg-hover: #000;
--service-map-input-bg-focus: #000;
--service-map-input-flat-bg: #000;
--service-map-input-flat-bg-hover: #000;
--service-map-input-text: var(--hc-accent, #ffea00);
--service-map-input-placeholder: rgba(255, 234, 0, 0.92);

--input-bg: var(--service-map-input-bg);
--input-bg-hover: var(--service-map-input-bg-hover);
--input-bg-focus: var(--service-map-input-bg-focus);
--input-flat-bg: var(--service-map-input-flat-bg);
--input-flat-bg-hover: var(--service-map-input-flat-bg-hover);
--input-text: var(--service-map-input-text);
--input-placeholder: var(--service-map-input-placeholder);
```

### `app/styles/features/service-map/desktop/pre-inquiry-agent.css`

Pre-inquiry agenti vormiväljade väärtused liiguvad samasse service-map alias-mudelisse.

Enne:

```css
--input-text: var(--workspace-feature-field-text, var(--input-text, #243044));
--input-placeholder: var(
  --workspace-feature-field-placeholder,
  var(--input-placeholder, rgba(71, 85, 105, 0.72))
);
```

Pärast:

```css
--service-map-input-text: var(--workspace-feature-field-text, var(--input-text, #243044));
--service-map-input-placeholder: var(
  --workspace-feature-field-placeholder,
  var(--input-placeholder, rgba(71, 85, 105, 0.72))
);
--input-text: var(--service-map-input-text);
--input-placeholder: var(--service-map-input-placeholder);
```

## Eeldatav mõju tokeniauditis

| Mõõdik | Enne 13q | Pärast 13q |
|---|---:|---:|
| Form-control `feature-direct-definition` | 8 | 0 |
| Form-control `feature-bridge` | 47 | 55 |
| Service-map direct definitsioonid | 8 | 0 |
| Service-map bridge definitsioonid | 2 | 10 |
| Form-control `other` | 0 | 0 |
| Projekti `!important` arv | 2025 | 2025 |

## Staatiline kontroll selles keskkonnas

Reaalset `git apply --check`, `npm run css:tokens` ja `npm run css:tokens:check` käivitust ei saanud siin teha, sest aktiivses tööruumis ei ole projekti repot ega 13p-järgset tööpuud. Patch on koostatud 13p raporti ja 13p-järgse tokeniauditi põhjal.

Rakenda päris repos pärast patch’i 34:

```bash
git apply --check sotsiaalai-css-cleanup-35-service-map-form-control-bridge.patch
git apply sotsiaalai-css-cleanup-35-service-map-form-control-bridge.patch

npm run css:tokens
npm run css:tokens:check
```

Oodatav kontrollitulemus:

```text
Form-control feature direct definitions: 0
Form-control feature bridge definitions: 55
Form-control other definitions: 0
Project CSS !important count: 2025
```

## Järgmine samm

Pärast 13q patch’i rakendamist sobib **13r kontroll-etapp**, kus uut refaktorit ei tehta. Kontrollida tuleb:

- form-control direct = 0;
- bridge arv ootuspärane;
- `other` = 0;
- `!important` ei suurenenud;
- CSS tokeniaudit ja CSS bundle ei halvene.
